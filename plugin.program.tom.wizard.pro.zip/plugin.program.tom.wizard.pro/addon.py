#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys,os,urllib,json,shutil
import inputstreamhelper
import xbmc,xbmcgui,xbmcplugin,xbmcaddon,xbmcvfs
from urllib.parse import urlparse
__plugin_handle__ = int(sys.argv[1])

def __fix_encoding__(path):
	if sys.platform.startswith('win'):return path
	else:return path # .encode('ISO-8859-1')

__server_url__ = str('')
__server_username__ = str('')
__server_password__ = str('')
__server_encoding__ = str('')

__addon__ =  xbmcaddon.Addon()
__addon_id__ = __addon__.getAddonInfo('id')
__addon_version__ = __addon__.getAddonInfo('version')
__addon_path__ = __fix_encoding__(__addon__.getAddonInfo('path'))
__addon_icon__ = __fix_encoding__(__addon__.getAddonInfo('icon'))
__addon_fanart__ = __fix_encoding__(__addon__.getAddonInfo('fanart'))

__cdm_path__ = __fix_encoding__(xbmcvfs.translatePath('special://home/cdm'))
__inputstream_path__ = __fix_encoding__(xbmcvfs.translatePath('special://home/addons/inputstream.adaptive'))

__home_path__ = __fix_encoding__(xbmcvfs.translatePath('special://home'))
__addons_path__ = __fix_encoding__(xbmcvfs.translatePath('special://home/addons'))
__addon_data_path__ = __fix_encoding__(xbmcvfs.translatePath('special://userdata/addon_data'))

__temp_path__ = __fix_encoding__(xbmcvfs.translatePath('special://temp'))
__thumbnails_path__ = __fix_encoding__(xbmcvfs.translatePath('special://thumbnails'))
__packages_path__ = __fix_encoding__(xbmcvfs.translatePath('special://home/addons/packages'))

__log_file_path__ = __fix_encoding__(xbmcvfs.translatePath('special://logpath/kodi.log'))
__error_log_file_path__ = os.path.abspath(os.path.join(__addon_path__,'kodi.log'))

sys.path.append(os.path.join(__addon_path__,'resources','lib'))
import activator,server,extractor,packer,downloader,cleaner,close,reader,repo


def __set_setting_item_view_mode__():
	item_view_mode = str(xbmcgui.Window(xbmcgui.getCurrentWindowId()).getFocusId())
	if item_view_mode:
		__addon__.setSetting('set_item_view_mode',item_view_mode)
		xbmcgui.Dialog().notification(heading='[COLOR blue]ITEM VIEW MODE[/COLOR]',message='Set item view mode : {0}'.format(item_view_mode),icon=xbmcgui.NOTIFICATION_INFO,time=3000,sound=True)

def __set_setting_info_view_mode__():
	info_view_mode = str(xbmcgui.Window(xbmcgui.getCurrentWindowId()).getFocusId())
	if info_view_mode:
		__addon__.setSetting('set_info_view_mode',info_view_mode)
		xbmcgui.Dialog().notification(heading='[COLOR blue]INFO VIEW MODE[/COLOR]',message='Set info view mode : {0}'.format(info_view_mode),icon=xbmcgui.NOTIFICATION_INFO,time=3000,sound=True)

def __set_item_content_and_view_mode__():
	set_item_content = __addon__.getSetting('set_item_content')
	if set_item_content:xbmcplugin.setContent(__plugin_handle__,set_item_content)
	set_item_view_mode = __addon__.getSetting('set_item_view_mode')
	if set_item_view_mode:xbmc.executebuiltin('Container.SetViewMode({0})'.format(set_item_view_mode))

def __set_info_content_and_view_mode__():
	set_info_content = __addon__.getSetting('set_info_content')
	if set_info_content:xbmcplugin.setContent(__plugin_handle__,set_info_content)
	set_info_view_mode = __addon__.getSetting('set_info_view_mode')
	if set_info_view_mode:xbmc.executebuiltin('Container.SetViewMode({0})'.format(set_info_view_mode))


if __addon__.getSetting('download_cfg') == 'true':
	__addon__.setSetting('download_cfg','false')

	cfg_url = __addon__.getSetting('cfg_url').strip()
	if cfg_url:
		cfg_username = __addon__.getSetting('cfg_username').strip()
		cfg_password = __addon__.getSetting('cfg_password').strip()
		
		cfg_path = os.path.join(__addon_data_path__,__addon_id__)
		cfg_file_path = os.path.join(__addon_data_path__,__addon_id__,'settings.xml')
		
		if  os.path.exists(cfg_file_path):
			os.remove(cfg_file_path)
		else:
			if not os.path.exists(cfg_path):
				os.makedirs(cfg_path)

		downloader.download_cfg_file(url=cfg_url,cfg_file_path=cfg_file_path,auth=(cfg_username,cfg_password),timeout=30,headers={})


if __addon__.getSetting('selected_server') == '1':
	__server_url__ = __addon__.getSetting('server_1_url').strip()
	if __server_url__:
		if not __server_url__.endswith('/'):__server_url__ += '/'
		__server_username__ = __addon__.getSetting('server_1_username').strip()
		__server_password__ = __addon__.getSetting('server_1_password').strip()
		__server_encoding__ = __addon__.getSetting('server_1_encoding').strip()

elif __addon__.getSetting('selected_server') == '2':
	__server_url__ = __addon__.getSetting('server_2_url').strip()
	if __server_url__:
		if not __server_url__.endswith('/'):__server_url__ += '/'
		__server_username__ = __addon__.getSetting('server_2_username').strip()
		__server_password__ = __addon__.getSetting('server_2_password').strip()
		__server_encoding__ = __addon__.getSetting('server_2_encoding').strip()

elif __addon__.getSetting('selected_server') == '3':
	__server_url__ = __addon__.getSetting('server_3_url').strip()
	if __server_url__:
		if not __server_url__.endswith('/'):__server_url__ += '/'
		__server_username__ = __addon__.getSetting('server_3_username').strip()
		__server_password__ = __addon__.getSetting('server_3_password').strip()
		__server_encoding__ = __addon__.getSetting('server_3_encoding').strip()

elif __addon__.getSetting('selected_server') == '4':
	__server_url__ = __addon__.getSetting('server_4_url').strip()
	if __server_url__:
		if not __server_url__.endswith('/'):__server_url__ += '/'
		__server_username__ = __addon__.getSetting('server_4_username').strip()
		__server_password__ = __addon__.getSetting('server_4_password').strip()
		__server_encoding__ = __addon__.getSetting('server_4_encoding').strip()

elif __addon__.getSetting('selected_server') == '5':
	__server_url__ = __addon__.getSetting('server_5_url').strip()
	if __server_url__:
		if not __server_url__.endswith('/'):__server_url__ += '/'
		__server_username__ = __addon__.getSetting('server_5_username').strip()
		__server_password__ = __addon__.getSetting('server_5_password').strip()
		__server_encoding__ = __addon__.getSetting('server_5_encoding').strip()


__zip_password__ = __addon__.getSetting('zip_password')
__addon_id_list__ = [__addon_id__,'script.module.inputstreamhelper']
__cleaner_save_list__ = [__addon_id__,'script.module.inputstreamhelper','Addons27.db','Textures13.db','kodi.log']
__extract_save_list__ = [__addon_id__,'script.module.inputstreamhelper']

if __addon__.getSetting('save_sources') == 'true':
	__cleaner_save_list__ += ['sources.xml']
	__extract_save_list__ += ['sources.xml']

if __addon__.getSetting('save_favourites') == 'true':
	__cleaner_save_list__ += ['favourites.xml']
	__extract_save_list__ += ['favourites.xml']

if __addon__.getSetting('save_advancedsettings') == 'true':
	__cleaner_save_list__ += ['advancedsettings.xml']
	__extract_save_list__ += ['advancedsettings.xml']


def __xbmc_sleep_ms__(ms):
	xbmc.sleep(ms)

def __update_repos_and_addons__():  
	xbmc.executebuiltin('UpdateAddonRepos')
	xbmc.executebuiltin('UpdateLocalAddons') 

def __reload_profile__():
	profil=xbmc.getInfoLabel('System.ProfileName') 
	if profil:xbmc.executebuiltin('LoadProfile('+profil+',prompt)')


def __check_inputstream__():
    if inputstreamhelper.Helper('mpd',drm='com.widevine.alpha').check_inputstream():
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","id":1,"params":{"addonid":"inputstream.adaptive", "enabled":true}}')    

def __delete_inputstream__():
	if os.path.exists(__cdm_path__):
		shutil.rmtree(__cdm_path__,ignore_errors=True)
	if os.path.exists(__inputstream_path__):
		shutil.rmtree(__inputstream_path__,ignore_errors=True)

	if not os.path.exists(__cdm_path__) and not os.path.exists(__inputstream_path__):
		xbmcgui.Dialog().ok('[COLOR blue]INPUTSTREAM UNINSTALLER[/COLOR]','Inputstream has been removed !')
	else:xbmcgui.Dialog().ok('[COLOR red]INPUTSTREAM UNINSTALLER ERROR[/COLOR]','The input stream could not be removed !')


def __show_picture__(url=''):
	xbmc.executebuiltin('ShowPicture(%s)' % (url))

def __text_viewer__(text=''):
	xbmcgui.Dialog().textviewer('[COLOR blue]INFO VIEWER[/COLOR]',text)

def __dialog_ok__(heading='',text=''):
	return xbmcgui.Dialog().ok(heading,text)

def __dialog_yes_no__(heading='',text='',nolabel='No',yeslabel='Yes',autoclose=0):
	return xbmcgui.Dialog().yesno(heading,text,nolabel=nolabel,yeslabel=yeslabel,autoclose=autoclose)

def __dialog_browse__(type=0,heading='',shares='files',mask='',useThumbs=False,treatAsFolder=False,defaultt='',enableMultiple=False):
	return xbmcgui.Dialog().browse(type=type,heading=heading,shares=shares,mask=mask,useThumbs=useThumbs,treatAsFolder=treatAsFolder,defaultt=defaultt,enableMultiple=enableMultiple)


def __add_item__(url='',title='',image='',fanart='',info_labels_update={},params_update={},add_contextmenu =[],imode='',is_folder=True,is_playable=False):

	iparams = {'url':url,'title':title,'image':image,'fanart':fanart,'imode':imode}
	cparams = {'url':url,'title':title,'image':image,'fanart':fanart}
	iparams.update(params_update)
	cparams.update(params_update)

	info_labels = {'Title':title}
	info_labels.update(info_labels_update)

	listitem = xbmcgui.ListItem(label=title,path=url)
	listitem.setInfo(type='video',infoLabels=info_labels)
	listitem.setArt({'icon':image,'poster':image,'banner':image,'fanart':fanart})

	if (is_folder == True and is_playable== False):
		url = sys.argv[0] + '?' + urllib.parse.quote_plus(json.dumps(iparams))
		listitem.setProperty('IsPlayable','false')

	elif (is_folder == False and is_playable == False):
		url = sys.argv[0] + '?' + urllib.parse.quote_plus(json.dumps(iparams))
		listitem.setProperty('IsPlayable','true')

	elif (is_folder == False and is_playable == True):
		listitem.setProperty('IsPlayable','true')

	com = []
	for title,cmode in add_contextmenu:
		if title and cmode:
			cparams.update({'cmode':cmode})
			com.append((title,'XBMC.RunPlugin('+ sys.argv[0] + '?' + urllib.parse.quote_plus(json.dumps(cparams)) +')'))
	if com:listitem.addContextMenuItems(items=com,replaceItems=True)

	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=listitem,isFolder=is_folder)

def __get_params__():
	argv = urllib.parse.unquote_plus(sys.argv[2][1:])
	if argv.startswith('{') and argv.endswith('}'):return json.loads(argv)
	else:return None
__params__ = __get_params__()

def end_of_directory():
	xbmcplugin.endOfDirectory(handle=__plugin_handle__,succeeded=True,updateListing=False,cacheToDisc=True)


if __params__ is None:
	__add_item__(url='',title='[COLOR blue]Open cfg[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Open cfg[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='open_cfg',is_folder=True,is_playable=False)
	__add_item__(url='',title='[COLOR blue]Log reader[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Log reader[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='log_reader_menu',is_folder=True,is_playable=False)
	__add_item__(url='',title='[COLOR blue]Cleaner tools[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Cleaner tools[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='cleaner_tools_menu',is_folder=True,is_playable=False)
	__add_item__(url='',title='[COLOR blue]Install from zip[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Install from zip[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='Install_from_zip_menu',is_folder=True,is_playable=False)
	__add_item__(url='',title='[COLOR blue]Backup manager[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Backup manager[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='backup_manager_menu',is_folder=True,is_playable=False)
	__add_item__(url='',title='[COLOR blue]Repository manager[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Repository manager[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='repository_manager_menu',is_folder=True,is_playable=False)
	__add_item__(url='',title='[COLOR blue]Fix addons or settings[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Fix addons or settings[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='fix_addons_or_settings_menu',is_folder=True,is_playable=False)
	__add_item__(url='',title='[COLOR blue]Check or delete inputstream installation[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Check or delete inputstream installation[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='check_inputstream_installation_menu',is_folder=True,is_playable=False)
	__set_item_content_and_view_mode__()
	end_of_directory()


elif __params__.get('imode') == 'open_cfg':
	__addon__.openSettings()


elif __params__.get('imode') == 'log_reader_menu':
	__add_item__(url='',title='[COLOR blue]Log[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Log[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='log_reader_function_1',is_folder=True,is_playable=False)
	__add_item__(url='',title='[COLOR blue]IP log[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]IP log[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='log_reader_function_2',is_folder=True,is_playable=False)
	__set_item_content_and_view_mode__()
	end_of_directory()

elif __params__.get('imode') == 'log_reader_function_1':
	reader.read_log(addon=__addon__,log_file_path=__log_file_path__,error_log_file_path=__error_log_file_path__,log_mode='log')

elif __params__.get('imode') == 'log_reader_function_2':
	reader.read_log(addon=__addon__,log_file_path=__log_file_path__,error_log_file_path=__error_log_file_path__,log_mode='ip_log')


elif __params__.get('imode') == 'cleaner_tools_menu':
	__add_item__(url='',title='[COLOR blue]Fresh start[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Fresh start[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='cleaner_tools_function_1',is_folder=True,is_playable=False)
	__add_item__(url='',title='[COLOR blue]Delete addon[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Delete addon[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='cleaner_tools_function_2',is_folder=True,is_playable=False)
	__add_item__(url='',title='[COLOR blue]Delete settins[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Delete settins[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='cleaner_tools_function_3',is_folder=True,is_playable=False)
	__add_item__(url='',title='[COLOR blue]Clean temp and packages[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Clean temp and packages[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='cleaner_tools_function_4',is_folder=True,is_playable=False)
	__add_item__(url='',title='[COLOR blue]Delete thumbnails directory[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Delete thumbnails directory[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='cleaner_tools_function_5',is_folder=True,is_playable=False)
	__set_item_content_and_view_mode__()
	end_of_directory()

elif __params__.get('imode') == 'cleaner_tools_function_1':
	check = cleaner.clean_dir(dir_path=__home_path__,cleaner_save_list=__cleaner_save_list__)
	if check:
		__xbmc_sleep_ms__(500)
		activator.enable_addon(addon_id_list=__addon_id_list__)
		__xbmc_sleep_ms__(500)
		close.close_kodi(__home_path__)

elif __params__.get('imode') == 'cleaner_tools_function_2':
	for data_dict in cleaner.list_directory(__addons_path__):
		__add_item__(url=data_dict['dir_path'],title='[COLOR lime]' + data_dict['dir_name'] + '[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]' + data_dict['dir_name'] + '[/COLOR]'},params_update={'dir_name':data_dict['dir_name'],'type':data_dict['type']},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='cleaner_tools_function_2_1',is_folder=True,is_playable=False)
	__set_item_content_and_view_mode__()
	end_of_directory()

elif __params__.get('imode') == 'cleaner_tools_function_2_1':
	if not __params__.get('dir_name') == __addon_id__:
		if __params__.get('type') == 'file':
			cleaner.delete_file( __params__.get('url'))
		elif __params__.get('type') == 'dir':
			cleaner.delete_directory( __params__.get('url'))
		xbmc.executebuiltin('Container.Refresh')

elif __params__.get('imode') == 'cleaner_tools_function_3':
	for data_dict in cleaner.list_directory(__addon_data_path__):
		__add_item__(url=data_dict['dir_path'],title='[COLOR lime]' + data_dict['dir_name'] + '[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]' + data_dict['dir_name'] + '[/COLOR]'},params_update={'dir_name':data_dict['dir_name'],'type':data_dict['type']},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='cleaner_tools_function_2_1',is_folder=True,is_playable=False)
	__set_item_content_and_view_mode__()
	end_of_directory()

elif __params__.get('imode') == 'cleaner_tools_function_3_1':
	if not __params__.get('dir_name') == __addon_id__:
		if __params__.get('type') == 'file':
			cleaner.delete_file( __params__.get('url'))
		elif __params__.get('type') == 'dir':
			cleaner.delete_directory( __params__.get('url'))
		xbmc.executebuiltin('Container.Refresh')

elif __params__.get('imode') == 'cleaner_tools_function_4':
	cleaner.clean_temp_and_Packages(temp_path=__temp_path__,packages_path=__packages_path__)

elif __params__.get('imode') == 'cleaner_tools_function_5':
	cleaner.clean_thumbnails(thumbnails_path=__thumbnails_path__)
	__xbmc_sleep_ms__(500)
	__reload_profile__()


elif __params__.get('imode') == 'Install_from_zip_menu':
	xbmc.executebuiltin('InstallFromZip')
	

elif __params__.get('imode') == 'backup_manager_menu':
	__add_item__(url='',title='[COLOR blue]Load backup from zip[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Load backup from zip[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='backup_manager_function_1',is_folder=True,is_playable=False)
	__add_item__(url='',title='[COLOR blue]Load backups from server[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Load backups from server[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='backup_manager_function_2',is_folder=True,is_playable=False)
	__add_item__(url='',title='[COLOR blue]Save the Kodi data in a backup zip file[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Save the Kodi data in a backup zip file[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='backup_manager_function_3',is_folder=True,is_playable=False)
	__set_item_content_and_view_mode__()
	end_of_directory()

elif __params__.get('imode') == 'backup_manager_function_1':
	error = True 
	zip_path = __fix_encoding__(__dialog_browse__(type=1,heading='[COLOR blue]BACKUP ZIP FILE ?[/COLOR]',shares='files',mask='.zip',useThumbs=False,treatAsFolder=False,defaultt='',enableMultiple=False))
	if zip_path:
		if extractor.check_zip(zip_path=zip_path):
			__xbmc_sleep_ms__(500)
			check = cleaner.clean_dir(dir_path=__home_path__,cleaner_save_list=__cleaner_save_list__)
			if check:
				__xbmc_sleep_ms__(500)
				check = extractor.extract_zip(zip_path=zip_path,extract_path=__home_path__,zip_pwd=__zip_password__,extract_save_list=__extract_save_list__)
				if check:
					__xbmc_sleep_ms__(500)
					cleaner.clean_temp_and_Packages_and_thumbnails_silent(temp_path=__temp_path__,packages_path=__packages_path__,thumbnails_path=__thumbnails_path__)
					__xbmc_sleep_ms__(500)
					activator.enable_addon(addon_id_list=__addon_id_list__)
					error = False
					if error == False:close.close_kodi(__home_path__)
	else:error = False
	if error == True:__dialog_ok__('[COLOR red]FUNCTION ERROR[/COLOR]','The function performed was incomplete !')

elif __params__.get('imode') == 'backup_manager_function_2':
	backup_dict_list = server.get_backup_dict_list(url=__server_url__ + 'backups/',auth=(__server_username__,__server_password__),timeout=15,headers={},server_encoding=__server_encoding__)
	if backup_dict_list:
		for backup_dict in backup_dict_list:
			title = backup_dict['backup_name']
			url = backup_dict['backup_url']
			img = backup_dict['backup_img_url']
			plot = backup_dict['backup_plot_text']
			__add_item__(url=url,title='[COLOR lime]' + title + '[/COLOR]',image=img,fanart=__addon_fanart__,info_labels_update={'plot':plot},params_update={'plot':plot},add_contextmenu =[['[COLOR blue]Backup info[/COLOR]','install_info'],['[COLOR blue]Backup image[/COLOR]','install_image'],['[COLOR blue]Set info view mode[/COLOR]','set_info_view_mode']],imode='backup_manager_function_2_1',is_folder=True,is_playable=False)
		__set_info_content_and_view_mode__()
		end_of_directory()

elif __params__.get('imode') == 'backup_manager_function_2_1':
	error = True 
	zip_file = downloader.download_byte_content(url=__params__.get('url'),auth=(__server_username__,__server_password__),timeout=15,headers={})
	if zip_file:
		if extractor.check_zip(zip_path=zip_file):
			__xbmc_sleep_ms__(500)
			check = cleaner.clean_dir(dir_path=__home_path__,cleaner_save_list=__cleaner_save_list__)
			if check:
				__xbmc_sleep_ms__(500)
				check = extractor.extract_zip(zip_path=zip_file,extract_path=__home_path__,zip_pwd=__zip_password__,extract_save_list=__extract_save_list__)
				if check:
					__xbmc_sleep_ms__(500)
					cleaner.clean_temp_and_Packages_and_thumbnails_silent(temp_path=__temp_path__,packages_path=__packages_path__,thumbnails_path=__thumbnails_path__)
					__xbmc_sleep_ms__(500)
					activator.enable_addon(addon_id_list=__addon_id_list__)
					error = False
					if error == False:close.close_kodi(__home_path__)
	if error == True:__dialog_ok__('[COLOR red]FUNCTION ERROR[/COLOR]','The function performed was incomplete !')
	
elif __params__.get('imode') == 'backup_manager_function_3':
	dir_path = __fix_encoding__(__dialog_browse__(type=0,heading='[COLOR blue]BACKUP ZIP SAVE PATH ?[/COLOR]',shares='files',mask='',useThumbs=False,treatAsFolder=False,defaultt='',enableMultiple=False))
	if dir_path:
		cleaner.clean_temp_and_Packages_and_thumbnails_silent(temp_path=__temp_path__,packages_path=__packages_path__,thumbnails_path=__thumbnails_path__)
		__xbmc_sleep_ms__(500)
		check = packer.zip_dir(dir_path=__home_path__,zip_save_path=dir_path,base_dir=False)
		if not check:__dialog_ok__('[COLOR red]FUNCTION ERROR[/COLOR]','The function performed was incomplete !')


elif __params__.get('imode') == 'repository_manager_menu':
	__add_item__(url='',title='[COLOR blue]Open repositories[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Open repository[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='repository_manager_function_1',is_folder=True,is_playable=False)
	__add_item__(url='',title='[COLOR blue]Check all repositories[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Open repository[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='repository_manager_function_2',is_folder=True,is_playable=False)
	__set_item_content_and_view_mode__()
	end_of_directory()

elif __params__.get('imode') == 'repository_manager_function_1':
	xbmc.executebuiltin('Dialog.Close(all,true)')
	xbmc.executebuiltin('ActivateWindow(AddonBrowser,addons://repos/)')

elif __params__.get('imode') == 'repository_manager_function_2':
	repo.repository_checker(addons_path=__addons_path__,timeout=15,headers={})


elif __params__.get('imode') == 'fix_addons_or_settings_menu':
	__add_item__(url='',title='[COLOR blue]Enable[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Enable[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='fix_addons_or_settings_function_1',is_folder=True,is_playable=False)
	__add_item__(url='',title='[COLOR blue]Disable[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Disable[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='fix_addons_or_settings_function_2',is_folder=True,is_playable=False)
	__add_item__(url='',title='[COLOR blue]Fix addons[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Fix addons[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='fix_addons_or_settings_function_3',is_folder=True,is_playable=False)
	__add_item__(url='',title='[COLOR blue]Fix settings[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Fix settings[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='fix_addons_or_settings_function_4',is_folder=True,is_playable=False)
	__add_item__(url='',title='[COLOR blue]Reload profile[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Reload profile[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='fix_addons_or_settings_function_5',is_folder=True,is_playable=False)
	__add_item__(url='',title='[COLOR blue]Update all addons[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Update all addons[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='fix_addons_or_settings_function_6',is_folder=True,is_playable=False)
	__set_item_content_and_view_mode__()
	end_of_directory()

elif __params__.get('imode') == 'fix_addons_or_settings_function_1':
	for data_dict in activator.list_addons(__addons_path__,enabled=False):
		__add_item__(url='',title='[COLOR lime]' + data_dict['dir_name'] + '[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]' + data_dict['dir_name'] + '[/COLOR]'},params_update={'addon_id':data_dict['addon_id']},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='fix_addons_or_settings_function_1_1',is_folder=True,is_playable=False)
	end_of_directory()

elif __params__.get('imode') == 'fix_addons_or_settings_function_1_1':
	activator.enable_addon(addon_id_list=[__params__.get('addon_id')])

elif __params__.get('imode') == 'fix_addons_or_settings_function_2':
	for data_dict in activator.list_addons(__addons_path__,enabled=True):
		__add_item__(url='',title='[COLOR lime]' + data_dict['dir_name'] + '[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]' + data_dict['dir_name'] + '[/COLOR]'},params_update={'addon_id':data_dict['addon_id']},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='fix_addons_or_settings_function_2_1',is_folder=True,is_playable=False)
	end_of_directory()

elif __params__.get('imode') == 'fix_addons_or_settings_function_2_1':
	activator.disable_addon(addon_id_list=[__params__.get('addon_id')])

elif __params__.get('imode') == 'fix_addons_or_settings_function_3':
	addons_or_settings_dict_list = server.get_addons_or_settings_dict_list(url=__server_url__ + 'addons/',auth=(__server_username__,__server_password__),timeout=15,headers={},server_encoding=__server_encoding__)
	if addons_or_settings_dict_list:
		for addons_or_settings_dict in addons_or_settings_dict_list:
			title = addons_or_settings_dict['addon_or_settings_name']
			url = addons_or_settings_dict['addon_or_settings_url']
			img = addons_or_settings_dict['addons_or_settings_image_url']
			plot = addons_or_settings_dict['addons_or_settings_plot_text']
			__add_item__(url=url,title='[COLOR lime]' + title + '[/COLOR]',image=img,fanart=__addon_fanart__,info_labels_update={'plot':plot},params_update={'original_title':title,'plot':plot},add_contextmenu =[['[COLOR blue]Addon info[/COLOR]','install_info'],['[COLOR blue]Addon image[/COLOR]','install_image'],['[COLOR blue]Set info view mode[/COLOR]','set_info_view_mode']],imode='fix_addons_or_settings_function_3_1',is_folder=True,is_playable=False)
		__set_info_content_and_view_mode__()
		end_of_directory()

elif __params__.get('imode') == 'fix_addons_or_settings_function_3_1':
	error = True 
	addon_path = os.path.join(__addons_path__,__params__.get('original_title'))
	def run():
		error = True 
		zip_file = downloader.download_byte_content(url=__params__.get('url'),auth=(__server_username__,__server_password__),timeout=15,headers={})
		if zip_file:
			__xbmc_sleep_ms__(500)
			check = cleaner.delete_addon_or_settings(addon_or_settings_path=addon_path)
			if check:
				__xbmc_sleep_ms__(500)
				extractor.extract_zip(zip_path=zip_file,extract_path=__addons_path__,zip_pwd=__zip_password__,extract_save_list=[])
				error = False
		return error

	if os.path.exists(addon_path):
		error = run()
	else:
		if  bool(__dialog_yes_no__('[COLOR red]FORBIDDEN ACTION[/COLOR]','No installation, just fix errors !\nContinue anyway ?',nolabel='[COLOR red]No[/COLOR]',yeslabel='[COLOR lime]Yes[/COLOR]',autoclose=0)):
			error = run()
		else:error = False
	if error == True:__dialog_ok__('[COLOR red]FUNCTION ERROR[/COLOR]','The function performed was incomplete !')

elif __params__.get('imode') == 'fix_addons_or_settings_function_4':
	addons_or_settings_dict_list = server.get_addons_or_settings_dict_list(url=__server_url__ + 'settings/',auth=(__server_username__,__server_password__),timeout=15,headers={},server_encoding=__server_encoding__)
	if addons_or_settings_dict_list:
		for addons_or_settings_dict in addons_or_settings_dict_list:
			title = addons_or_settings_dict['addon_or_settings_name']
			url = addons_or_settings_dict['addon_or_settings_url']
			img = addons_or_settings_dict['addons_or_settings_image_url']
			plot = addons_or_settings_dict['addons_or_settings_plot_text']
			__add_item__(url=url,title='[COLOR lime]' + title + '[/COLOR]',image=img,fanart=__addon_fanart__,info_labels_update={'plot':plot},params_update={'original_title':title,'plot':plot},add_contextmenu =[['[COLOR blue]Setting info[/COLOR]','install_info'],['[COLOR blue]Settings image[/COLOR]','install_image'],['[COLOR blue]Set info view mode[/COLOR]','set_info_view_mode']],imode='fix_addons_or_settings_function_4_1',is_folder=True,is_playable=False)
		__set_info_content_and_view_mode__()
		end_of_directory()

elif __params__.get('imode') == 'fix_addons_or_settings_function_4_1':
	error = True 
	addon_settings_path = os.path.join(__addon_data_path__,__params__.get('original_title'))
	def run():
		error = True 
		zip_file = downloader.download_byte_content(url=__params__.get('url'),auth=(__server_username__,__server_password__),timeout=15,headers={})
		if zip_file:
			__xbmc_sleep_ms__(500)
			check = cleaner.delete_addon_or_settings(addon_or_settings_path=addon_settings_path)
			if check:
				__xbmc_sleep_ms__(500)
				extractor.extract_zip(zip_path=zip_file,extract_path=__addon_data_path__,zip_pwd=__zip_password__,extract_save_list=[])
				error = False
		return error

	if os.path.exists(addon_settings_path):
		error = run()
	else:
		if  bool(__dialog_yes_no__('[COLOR red]FORBIDDEN ACTION[/COLOR]','No installation, just fix errors !\nContinue anyway ?',nolabel='[COLOR red]No[/COLOR]',yeslabel='[COLOR lime]Yes[/COLOR]',autoclose=0)):
			error = run()
		else:error = False
	if error == True:pass__dialog_ok__('[COLOR red]FUNCTION ERROR[/COLOR]','The function performed was incomplete !')

elif __params__.get('imode') == 'fix_addons_or_settings_function_5':
	__reload_profile__()
elif __params__.get('imode') == 'fix_addons_or_settings_function_6':
	__update_repos_and_addons__()


elif __params__.get('imode') == 'check_inputstream_installation_menu':
	__add_item__(url='',title='[COLOR blue]Check inputstream[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Check inputstream[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='check_inputstream_installation_function_1',is_folder=True,is_playable=False)
	__add_item__(url='',title='[COLOR blue]Delete inputstream[/COLOR]',image=__addon_icon__,fanart=__addon_fanart__,info_labels_update={'plot':'[COLOR blue]Delete inputstream[/COLOR]'},params_update={},add_contextmenu =[['[COLOR blue]Set item view mode[/COLOR]','set_item_view_mode']],imode='check_inputstream_installation_function_2',is_folder=True,is_playable=False)
	__set_item_content_and_view_mode__()
	end_of_directory()

elif __params__.get('imode') == 'check_inputstream_installation_function_1':
	__check_inputstream__()
elif __params__.get('imode') == 'check_inputstream_installation_function_2':
	__delete_inputstream__()


elif __params__.get('cmode') == 'install_info':
	plot = __params__.get('plot')
	if plot:__text_viewer__(text=plot)

elif __params__.get('cmode') == 'install_image':
	image = __params__.get('image')
	if image:__show_picture__(url=image)

elif __params__.get('cmode') == 'set_item_view_mode':
	__set_setting_item_view_mode__()

elif __params__.get('cmode') == 'set_info_view_mode':
	__set_setting_info_view_mode__()